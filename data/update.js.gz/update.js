const gateway = `ws://${window.location.hostname}/ws`;
var websocket;
window.addEventListener('load', onload);

// Global variables for mini-chart data
let miniRssi = 0;
let currentTemperature = undefined;
let currentHumidity = undefined;
let currentPressure = undefined;
let currentWindSpeed = undefined;
let currentRainHour = undefined;

// Global variable for the historical temperature SVG chart object/instance
let historicalTempSVGChartObject;
let historicalHumSVGChartObject;
let historicalPresSVGChartObject;
let historicalWindSVGChartObject;
let historicalRainSVGChartObject;
let historicalBattVoltSVGChartObject;

// Mini-chart instances for backfill
const miniChartInstances = {};

// Helper to reorder circular buffer data
const reorderData = (arr, startIndex) => {
    if (!arr || startIndex === undefined || startIndex === 0) return arr;
    const points = arr.length;
    const index = startIndex % points;
    return arr.slice(index).concat(arr.slice(0, index));
};

// Define HISTORICAL_CHART_POINTS for the 24-hour (10-min avg) SVG chart
const HISTORICAL_CHART_POINTS = 144; // 24 hours * 6 points/hour

// Define HISTORICAL_DATA_POINTS for the ESP32's 1-minute resolution buffer (used for fullDayData)
const HISTORICAL_DATA_POINTS = 1440; // 24 hours * 60 minutes

// Client-side buffer for 24 hours of data, 5 sensors
const EMPTY_HOUR_DATA = () => ({
    tempData: new Array(60).fill(null),
    humData: new Array(60).fill(null),
    presData: new Array(60).fill(null),
    rainData: new Array(60).fill(null),
    windData: new Array(60).fill(null),
    windDirData: new Array(60).fill(null)
});
let fullDayData = new Array(24).fill(null).map(EMPTY_HOUR_DATA);
let clientOverallHistoryStartIndex = 0;
let expectedHourlyChunks = 24; // For the old chunking mechanism, if ever re-enabled
let receivedHourlyChunks = 0;  // For the old chunking mechanism

// --- Responsive Chart Handling ---
let activeChartsForResize = []; // Will only contain mini-charts after this revert

function onload(event) {
    initWebSocket();
    rearrangeNav();
    initSidebarToggle();
    initializeAllMiniCharts();
    initializeAllHistoricalSVGCharts(); // Initialize all SVG historical charts
    initWindRoseSVG(); // Initialize the wind rose petals
    darkmode();
}

function initSidebarToggle() {
    const toggleBtn = document.getElementById('sidebarToggle');
    if (!toggleBtn) return;
    const toggleText = toggleBtn.querySelector('.nav-text');

    // Load initial state
    const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    if (isCollapsed && window.innerWidth >= 768) {
        document.body.classList.add('sidebar-collapsed');
        if (toggleText) toggleText.innerText = 'Expand';
    }

    toggleBtn.addEventListener('click', () => {
        document.body.classList.toggle('sidebar-collapsed');
        const nowCollapsed = document.body.classList.contains('sidebar-collapsed');
        localStorage.setItem('sidebarCollapsed', nowCollapsed);
        
        if (toggleText) {
            toggleText.innerText = nowCollapsed ? 'Expand' : 'Collapse';
        }

        // Trigger resize event after transition to re-calculate charts
        setTimeout(() => {
            window.dispatchEvent(new Event('resize'));
        }, 310);
    });
}

function rearrangeNav() {
    const desktopStats = document.getElementById("desktop-stats");
    const mobileStats = document.getElementById("mobile-stats");
    const statsHTML = '<ul><li><span id="loadVoltage">Pending</span> V</li><li><span id="currentmA">Pending</span> mA</li><li><span id="power_mW">Pending</span> mW</li><li><span id="rssi">Pending</span> dB</li><li><span id="timeStamp">Pending</span></li></ul>';
    const desktopUniqueHTML = '<strong style="margin-right: 12px;">Status</strong>';

    if (!desktopStats || !mobileStats) return;

    mobileStats.innerHTML = '';
    desktopStats.innerHTML = '';

    if (document.body.clientWidth <= 922) { // MOBILE
        mobileStats.insertAdjacentHTML('afterbegin', statsHTML);
    } else { // DESKTOP
        let desktopVersionStatsHTML = statsHTML.replace('<ul><li>', `<ul><li>${desktopUniqueHTML}</li><li>`);
        desktopStats.insertAdjacentHTML('afterbegin', desktopVersionStatsHTML);
    }
}

function getValues() {
    if (websocket && websocket.readyState === WebSocket.OPEN) {
        websocket.send("getValues");
        console.log('Sent: getValues');
    } else {
        console.log('WebSocket not open. Cannot send getValues.');
    }
}

let reconnectIntervalId = null;
let watchdogIntervalId = null;
let lastMessageTime = Date.now();
const WATCHDOG_TIMEOUT = 10000; // 10 seconds

function initWebSocket() {
    console.log('Trying to open a WebSocket connection…');
    websocket = new WebSocket(gateway);
    websocket.onopen = onOpen;
    websocket.onclose = onClose;
    websocket.onmessage = onMessage;
    startWatchdog();
}

function startWatchdog() {
    if (watchdogIntervalId) clearInterval(watchdogIntervalId);

    // Reset timer on start
    lastMessageTime = Date.now();

    watchdogIntervalId = setInterval(() => {
        const now = Date.now();
        // Only check if socket is theoretically open
        if (websocket && websocket.readyState === WebSocket.OPEN) {
            if (now - lastMessageTime > WATCHDOG_TIMEOUT) {
                console.warn("Watchdog: No data received for " + (now - lastMessageTime) + "ms. detecting disconnect.");
                websocket.close(); // This will trigger onClose, which updates UI and retries
            }
        }
    }, 2000); // Check every 2 seconds
}

function onOpen(event) {
    console.log('Connection opened');
    if (reconnectIntervalId) {
        clearTimeout(reconnectIntervalId);
        reconnectIntervalId = null;
    }

    // Reset Watchdog
    lastMessageTime = Date.now();

    // Update Status UI
    const statusEl = document.getElementById('wsStatus');
    const statusDot = document.getElementById('wsStatusDot');
    if (statusEl) {
        statusEl.innerText = "Connected";
        statusEl.style.color = "var(--bs-success)";
        statusEl.style.fontWeight = "bold";
    }
    if (statusDot) {
        statusDot.classList.remove('offline');
        statusDot.classList.add('online');
    }

    getValues();
    requestFullHistory(); 
}

function onClose(event) {
    console.log('Connection closed');

    // Update Status UI
    const statusEl = document.getElementById('wsStatus');
    const statusDot = document.getElementById('wsStatusDot');
    if (statusEl) {
        statusEl.innerText = "Disconnected";
        statusEl.style.color = "var(--bs-danger)";
        statusEl.style.fontWeight = "bold";
    }
    if (statusDot) {
        statusDot.classList.remove('online');
        statusDot.classList.add('offline');
    }

    if (!reconnectIntervalId) {
        reconnectIntervalId = setTimeout(initWebSocket, 3000);
    }
}

const updateElement = (id, val, toFixedDigits = -1) => {
    const el = document.getElementById(id);
    if (el) {
        let displayValue = val;
        if (typeof val === 'number' && !isNaN(val) && toFixedDigits >= 0) {
            displayValue = val.toFixed(toFixedDigits);
        }
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
            el.value = displayValue;
            if (el.type === 'number' && el.placeholder !== undefined && (id.startsWith("Fdata") || ["dataRefresh", "rssilimit", "wifiinterval", "windRainCutoff", "deepSleepTime"].includes(id))) {
                el.placeholder = displayValue;
            }
        } else {
            el.innerHTML = displayValue;
        }
    }
};

function onMessage(event) {
    // Watchdog kick
    lastMessageTime = Date.now();

    let data;
    try {
        data = JSON.parse(event.data);
        console.log("Raw data:", event.data);
    } catch (e) {
        console.error("Failed to parse JSON from WebSocket:", e, "Raw data:", event.data);
        if (typeof event.data === 'string' && document.getElementById("terminalBoxAreaID")) {
            const textarea = document.getElementById("terminalBoxAreaID");
            textarea.value += event.data + "\n";
            textarea.scrollTop = textarea.scrollHeight;
        }
        return;
    }

    if (data.historyDataType === "histHourData") {
        console.log("Received hourly historical chunk for hourOffset:", data.hourOffset);
        if (receivedHourlyChunks === 0) {
            clientOverallHistoryStartIndex = data.historyStartIndex;
        }
        const hourOffset = data.hourOffset;
        if (hourOffset >= 0 && hourOffset < 24) {
            fullDayData[hourOffset] = { // Still populate fullDayData for potential other uses
                tempData: data.tempData || EMPTY_HOUR_DATA().tempData,
                humData: data.humData || EMPTY_HOUR_DATA().humData,
                presData: data.presData || EMPTY_HOUR_DATA().presData,
                rainData: data.rainData || EMPTY_HOUR_DATA().rainData,
                windData: data.windData || EMPTY_HOUR_DATA().windData,
                windDirData: data.windDirData || EMPTY_HOUR_DATA().windDirData
            };
        }
        receivedHourlyChunks++;
        if (receivedHourlyChunks >= expectedHourlyChunks) {
            console.log("All 24 (old style) hourly historical chunks received and stored in fullDayData.");
            receivedHourlyChunks = 0;
        } // End of histHourData
    } else if (data.historyDataType === "hist24h_10minAvgData") {
        console.log("Received historical data.");

        // New: Read display duration and interval from the server
        const displayHours = data.displayHours || 24; // Default to 24 hours if not provided
        const minutesPerPoint = data.minutesPerPoint || (displayHours * 60 / HISTORICAL_CHART_POINTS); // Default to 10 min/point if not provided

        const millisPerChartPoint = minutesPerPoint * 60 * 1000; // Calculate milliseconds per chart point

        // Update chart titles to reflect the actual display duration
        historicalTempSVGChartObject.updateTitle("Temperature (" + displayHours.toFixed(1) + "h)");
        historicalHumSVGChartObject.updateTitle("Humidity (" + displayHours.toFixed(1) + "h)");
        historicalPresSVGChartObject.updateTitle("Air Pressure (" + displayHours.toFixed(1) + "h)");
        historicalWindSVGChartObject.updateTitle("Wind Speed (" + displayHours.toFixed(1) + "h)");
        historicalRainSVGChartObject.updateTitle("Rainfall (" + displayHours.toFixed(1) + "h)");
        historicalBattVoltSVGChartObject.updateTitle("Battery Voltage (" + displayHours.toFixed(1) + "h)");

        // Helper to reorder circular buffer data
        const reorderDataInner = (arr, startIndex) => {
            if (!arr || startIndex === undefined || startIndex === 0) return arr;
            return arr.slice(startIndex).concat(arr.slice(0, startIndex));
        };

        const startIndex = data.historyStartIndex !== undefined ? data.historyStartIndex : 0;
        const lastTs = data.lastPointTimestamp ? data.lastPointTimestamp * 1000 : new Date().getTime();
        const orderedTimestamps = reorderData(data.timestampData, startIndex);

        const getTimestamp = (index) => {
            if (orderedTimestamps && orderedTimestamps[index]) {
                return orderedTimestamps[index] * 1000;
            }
            // Fallback to legacy calculation if timestampData is missing or point is null
            return lastTs - ((HISTORICAL_CHART_POINTS - 1 - index) * millisPerChartPoint);
        };

        if (historicalTempSVGChartObject && data.tempData && data.tempData.length === HISTORICAL_CHART_POINTS) { // Expect 144 points
            const orderedTemp = reorderDataInner(data.tempData, startIndex);
            let seriesDataForChart = [];
            for (let i = 0; i < HISTORICAL_CHART_POINTS; i++) {
                seriesDataForChart.push([getTimestamp(i), orderedTemp[i]]);
            }
            if (historicalHumSVGChartObject && data.humData && data.humData.length === HISTORICAL_CHART_POINTS) {
                const orderedHum = reorderDataInner(data.humData, startIndex);
                let seriesHumData = [];
                for (let i = 0; i < HISTORICAL_CHART_POINTS; i++) {
                    seriesHumData.push([getTimestamp(i), orderedHum[i]]);
                }
                historicalHumSVGChartObject.updateFullData(seriesHumData);
            }
            if (historicalPresSVGChartObject && data.presData && data.presData.length === HISTORICAL_CHART_POINTS) {
                const orderedPres = reorderDataInner(data.presData, startIndex);
                let seriesPresData = [];
                for (let i = 0; i < HISTORICAL_CHART_POINTS; i++) {
                    seriesPresData.push([getTimestamp(i), orderedPres[i]]);
                }
                historicalPresSVGChartObject.updateFullData(seriesPresData);
            }
            if (historicalWindSVGChartObject && data.windData && data.windData.length === HISTORICAL_CHART_POINTS) {
                const orderedWind = reorderDataInner(data.windData, startIndex);
                const orderedGust = reorderDataInner(data.windGustData, startIndex);
                const orderedDir = reorderDataInner(data.windDirData, startIndex);

                let seriesWindData = [], seriesGustData = [], seriesDirData = [];
                for (let i = 0; i < HISTORICAL_CHART_POINTS; i++) {
                    const ts = getTimestamp(i);
                    seriesWindData.push([ts, orderedWind[i]]);
                    if (orderedGust && orderedGust.length === HISTORICAL_CHART_POINTS) {
                        seriesGustData.push([ts, orderedGust[i]]);
                    }
                    if (orderedDir && orderedDir.length === HISTORICAL_CHART_POINTS) {
                        seriesDirData.push([ts, orderedDir[i]]);
                    }
                }
                historicalWindSVGChartObject.updateFullData(seriesWindData, seriesGustData, seriesDirData);
                updateWindRose(orderedDir); // Update the wind rose UI
            } else {
                if (data.windData) {
                    console.warn("Received hist24h_10minAvgData but chart object or data is invalid/mismatched for wind.");
                }
            }
            if (historicalRainSVGChartObject && data.rainData && data.rainData.length === HISTORICAL_CHART_POINTS) {
                const orderedRain = reorderDataInner(data.rainData, startIndex);
                let seriesRainData = [];
                for (let i = 0; i < HISTORICAL_CHART_POINTS; i++) {
                    seriesRainData.push([getTimestamp(i), orderedRain[i]]);
                }
                historicalRainSVGChartObject.updateFullData(seriesRainData);
            }
            if (historicalBattVoltSVGChartObject && data.battVoltData && data.battVoltData.length === HISTORICAL_CHART_POINTS) {
                const orderedBatt = reorderDataInner(data.battVoltData, startIndex);
                let seriesBattVoltData = [];
                for (let i = 0; i < HISTORICAL_CHART_POINTS; i++) {
                    seriesBattVoltData.push([getTimestamp(i), orderedBatt[i]]);
                }
                historicalBattVoltSVGChartObject.updateFullData(seriesBattVoltData);
            }
            historicalTempSVGChartObject.updateFullData(seriesDataForChart);
        } else {
            console.warn("Received hist24h_10minAvgData but chart object or data is invalid/mismatched for temperature.");
            if (data.tempData) console.warn("Temp Data - Expected points: " + HISTORICAL_CHART_POINTS + ", Received: " + data.tempData.length);
        }
        // The fullDayData (1-min resolution) is not directly updated by this 10-min average message.
        // It's updated by "latestMinuteUpdate".
    } else if (data.historyDataType === "latestMinuteUpdate") { // This still handles 1-minute updates
        // console.log("Received latest minute update:", data.latestTemp);
        const latestDataIndexIn1440Buffer = data.latestDataIndex;



        // Update fullDayData (for potential other uses or if needed by a future 24h chart)
        let relativeMinuteIndex = (latestDataIndexIn1440Buffer - clientOverallHistoryStartIndex + HISTORICAL_DATA_POINTS) % HISTORICAL_DATA_POINTS;
        let hourForUpdate = Math.floor(relativeMinuteIndex / 60);
        let minuteInHourForUpdate = relativeMinuteIndex % 60;
        if (hourForUpdate >= 0 && hourForUpdate < 24 && fullDayData[hourForUpdate]) {
            if (data.latestTemp !== null) fullDayData[hourForUpdate].tempData[minuteInHourForUpdate] = data.latestTemp;
            if (data.latestHum !== null) fullDayData[hourForUpdate].humData[minuteInHourForUpdate] = data.latestHum;
            if (data.latestPres !== null) fullDayData[hourForUpdate].presData[minuteInHourForUpdate] = data.latestPres;
            if (data.latestRain !== null) fullDayData[hourForUpdate].rainData[minuteInHourForUpdate] = data.latestRain;
            if (data.latestWind !== null) fullDayData[hourForUpdate].windData[minuteInHourForUpdate] = data.latestWind;
            if (data.latestWindDir !== undefined) {
                fullDayData[hourForUpdate].windDirData[minuteInHourForUpdate] = data.latestWindDir;
                
                // Update the wind rose live
                // Flatten 24h data to get a simple array of valid directions
                const allRecentDirs = [];
                for (let h = 0; h < 24; h++) {
                    if (fullDayData[h] && fullDayData[h].windDirData) {
                        for (let m = 0; m < 60; m++) {
                            const val = fullDayData[h].windDirData[m];
                            if (val !== null && val !== undefined && val !== -1) {
                                allRecentDirs.push(val);
                            }
                        }
                    }
                }
                if (allRecentDirs.length > 0) {
                    updateWindRose(allRecentDirs);
                }
            }
        }
        // clientOverallHistoryStartIndex = (latestDataIndexIn1440Buffer + 1) % HISTORICAL_DATA_POINTS; // This might need re-evaluation if fullDayData isn't primary for charts

        // The 10-min average historical chart is NOT updated live by 1-minute data in this simplified version.
        // It will only update when the ESP32 sends a new "hist24h_10minAvgData" message
        // (e.g., on client reconnect, or if you implement a periodic resend from ESP32).
        // Mini-charts are updated by the live values below.
    } else if (data.historyDataType === "miniChartBackfill") {
        console.log("Received mini-chart backfill data.");
        const startIndex = data.miniChartIndex !== undefined ? data.miniChartIndex : 0;
        
        const updateMiniIfFound = (chartId, rawArray) => {
            const chart = miniChartInstances[chartId];
            if (chart && rawArray) {
                const ordered = reorderData(rawArray, startIndex);
                chart.setHistory(ordered);
            }
        };

        updateMiniIfFound("tempChart", data.temp);
        updateMiniIfFound("humidityChart", data.hum);
        updateMiniIfFound("pressureChart", data.pres);
        updateMiniIfFound("windSpeedChart", data.wind);
        updateMiniIfFound("rainChart", data.rain);

    } else { // This handles live data for dashboard elements and mini-chart source variables
        for (const key in data) {
            if (data.hasOwnProperty(key)) {
                const value = data[key];
                switch (key) {
                    // Handle System Configuration fields
                    case "ssid": updateElement('C_WIFI_SSID', value); break;
                    case "myChannelNumber": updateElement('C_TS_CH_ID', value); break;
                    case "thingSpkAPIwR": updateElement('C_TS_API_WR', value); break;
                    case "stationID": updateElement('C_WINDY_ST_ID', value); break;
                    case "windyAPIKey": updateElement('C_WINDY_API_KEY', value); break;
                    case "wundStationID": updateElement('C_WUND_ST_ID', value); break;
                    case "wundStationPw": updateElement('C_WUND_ST_PW', value); break;
                    case "PWSWxStationPw": updateElement('C_PWS_ST_PW', value); break;
                    case "mqttBroker": updateElement('C_MQTT_BROKER', value); break;
                    case "mqttPort": updateElement('C_MQTT_PORT', value); break;
                    case "mqttUser": updateElement('C_MQTT_USER', value); break;
                    case "mqttPass": updateElement('C_MQTT_PASS', value); break;
                    case "mqttTopic": updateElement('C_MQTT_TOPIC', value); break;

                    case "yourUTC":
                        const timezoneSelect = document.getElementById('C_TIMEZONE');
                        if (timezoneSelect) timezoneSelect.value = value;
                        break;
                    case "daylightOffset":
                        const daylightCheckbox = document.getElementById('C_DAYLIGHT_SAVINGS');
                        // Value will be 3600 for on, 0 for off.
                        if (daylightCheckbox) daylightCheckbox.checked = (value > 0);
                        break;

                    case "rssi": miniRssi = parseFloat(value) * -1; updateElement("rssi", value); break;
                    case "outsideTemp": currentTemperature = parseFloat(value); updateElement("outsideTemp", currentTemperature, 1); break;
                    case "sensorHum": currentHumidity = parseFloat(value); updateElement("sensorHum", currentHumidity, 1); break;
                    case "sensPress": currentPressure = parseFloat(value); updateElement("sensPress", currentPressure, 0); break;
                    case "windspeedKmH": currentWindSpeed = parseFloat(value); updateElement("windspeedKmH", currentWindSpeed, 1); break;
                    case "winddir":
                        const windDirValue = parseFloat(value);
                        updateElement("winddir", windDirValue, 0);
                        const winDirArrow = document.getElementById("arrow-wrapper");
                        if (winDirArrow) { winDirArrow.style.transform = `translateX(-50%) rotate(${windDirValue}deg)`; }
                        break;
                    case "windDirCd": updateElement("windDirCd", value); break;
                    case "version": updateElement("version", value); updateElement("firmware", value); break;
                    case "IPaddress": updateElement("IPaddress", value); break;
                    case "loadVoltage": updateElement("loadVoltage", parseFloat(value), 2); break;
                    case "currentmA": updateElement("currentmA", parseFloat(value), 0); break;
                    case "power_mW": updateElement("power_mW", parseFloat(value), 0); break;
                    case "timeStamp": updateElement("timeStamp", value); break;
                    case "freeHeapMem": updateElement("freeHeapMem", value); break;
                    case "memoryLFS": updateElement("memoryLFS", value); break;
                    case "windyStatus": updateElement("windyStatus", value); break;
                    case "wundStatus": updateElement("wundStatus", value); break;
                    case "thingStatus": updateElement("thingStatus", value); break;
                    case "mqttStatus": updateElement("mqttStatus", value); break;
                    case "nextMQTTAPITimeStr": updateElement("nextMQTTAPITimeStr", value); break;
                    case "rainHourMM": currentRainHour = parseFloat(value); updateElement("rainHourMM", currentRainHour, 1); break;
                    case "dailyrainMM": updateElement("dailyrainMM", parseFloat(value), 1); break;
                    case "uptime":
                        const ms = parseInt(value, 10);
                        const s = Math.floor(ms / 1000);
                        const d = Math.floor(s / 86400);
                        const h = Math.floor((s % 86400) / 3600);
                        const m = Math.floor((s % 3600) / 60);
                        const sec = s % 60;
                        const uptimeString = `${d}d ${h}h ${m}m ${sec}s`;
                        updateElement("uptime", uptimeString);
                        break;
                    case "windgustKmH": updateElement("windgustKmH", parseFloat(value), 1); break;
                    case "tempMin": updateElement("tempMin", parseFloat(value), 1); break;
                    case "tempMax": updateElement("tempMax", parseFloat(value), 1); break;
                    case "tempAvg": updateElement("tempAvg", parseFloat(value), 1); break;
                    case "humidityMin": updateElement("humidityMin", parseFloat(value), 1); break;
                    case "humidityMax": updateElement("humidityMax", parseFloat(value), 1); break;
                    case "humidityAvg": updateElement("humidityAvg", parseFloat(value), 1); break;
                    case "pressureMin": updateElement("pressureMin", parseFloat(value), 0); break;
                    case "pressureMax": updateElement("pressureMax", parseFloat(value), 0); break;
                    case "pressureAvg": updateElement("pressureAvg", parseFloat(value), 0); break;
                    case "windMin": updateElement("windMin", parseFloat(value), 1); break;
                    case "windMax": updateElement("windMax", parseFloat(value), 1); break;
                    case "windAvg": updateElement("windAvg", parseFloat(value), 1); break;
                    case "windGMin": updateElement("windGMin", parseFloat(value), 1); break;
                    case "windGMax": updateElement("windGMax", parseFloat(value), 1); break;
                    case "windGAvg": updateElement("windGAvg", parseFloat(value), 1); break;
                    case "rainPHMin": updateElement("rainPHMin", parseFloat(value), 1); break;
                    case "rainPHMax": updateElement("rainPHMax", parseFloat(value), 1); break;
                    case "rainPHMAvg": updateElement("rainPHMAvg", parseFloat(value), 1); break;
                    case "dataRefresh": updateElement("dataRefresh", value); updateElement("Fdata0", value); break;
                    case "rssilimit": updateElement("rssilimit", value); updateElement("Fdata2", value); break;
                    case "wifiinterval": updateElement("wifiinterval", value); updateElement("Fdata3", value); break;
                    case "windRainCutoff": updateElement("windRainCutoff", value); updateElement("Fdata4", value); break;
                    case "deepSleepTime": updateElement("deepSleepTime", value); updateElement("Fdata5", value); break;
                    case "terminal":
                        const textarea = document.getElementById("terminalBoxAreaID");
                        // This case now only handles terminal text output
                        if (textarea) {
                            textarea.value += value + "\n";
                            textarea.scrollTop = textarea.scrollHeight;
                        }
                        break;
                    default:
                        if (key.includes("toggle") && key !== "Dtoggle5") {
                            const toggleElement = document.getElementById(key);
                            if (toggleElement && typeof toggleElement.checked !== 'undefined') {
                                toggleElement.checked = (value == "1" || value === true || value === 1);
                            }
                        } else if (document.getElementById(key)) {
                            updateElement(key, value);
                        }
                        break;
                }
            }
        }
        updateDailyRangeBars(data);
    }
}

function updateDailyRangeBars(data) {
    // Helper to get value from data or fallback to DOM or global
    // We prefer data from the current packet.
    // Note: The main loop already updated text elements and some globals (currentTemperature, etc.)

    // Temperature
    let tMin = data.hasOwnProperty('tempMin') ? parseFloat(data.tempMin) : parseFloat(document.getElementById('tempMin').innerText);
    let tMax = data.hasOwnProperty('tempMax') ? parseFloat(data.tempMax) : parseFloat(document.getElementById('tempMax').innerText);
    let tCurr = data.hasOwnProperty('outsideTemp') ? parseFloat(data.outsideTemp) : currentTemperature;

    // Update the text display for the Record section
    if (!isNaN(tCurr)) updateElement('outsideTemp_Rec', tCurr, 1);

    if (!isNaN(tMin) && !isNaN(tMax) && !isNaN(tCurr)) {
        let bounds = getDynamicBounds(tMin, tMax, false);
        setRangeBar("tempRangeFill", "tempCurrentMarker", tCurr, tMin, tMax, bounds.min, bounds.max);
    }

    // Humidity
    let hMin = data.hasOwnProperty('humidityMin') ? parseFloat(data.humidityMin) : parseFloat(document.getElementById('humidityMin').innerText);
    let hMax = data.hasOwnProperty('humidityMax') ? parseFloat(data.humidityMax) : parseFloat(document.getElementById('humidityMax').innerText);
    let hCurr = data.hasOwnProperty('sensorHum') ? parseFloat(data.sensorHum) : currentHumidity;

    if (!isNaN(hCurr)) updateElement('sensorHum_Rec', hCurr, 1);

    if (!isNaN(hMin) && !isNaN(hMax) && !isNaN(hCurr)) {
        // Humidity is usually 0-100, but dynamic scaling helps if range is small (e.g. 40-60)
        let bounds = getDynamicBounds(hMin, hMax, false);
        setRangeBar("humRangeFill", "humCurrentMarker", hCurr, hMin, hMax, Math.max(0, bounds.min), Math.min(100, bounds.max));
    }

    // Pressure
    let pMin = data.hasOwnProperty('pressureMin') ? parseFloat(data.pressureMin) : parseFloat(document.getElementById('pressureMin').innerText);
    let pMax = data.hasOwnProperty('pressureMax') ? parseFloat(data.pressureMax) : parseFloat(document.getElementById('pressureMax').innerText);
    let pCurr = data.hasOwnProperty('sensPress') ? parseFloat(data.sensPress) : currentPressure;

    if (!isNaN(pCurr)) updateElement('sensPress_Rec', pCurr, 0);

    // Pressure varies less, so tight bounds are better for visualization.
    if (!isNaN(pMin) && !isNaN(pMax) && !isNaN(pCurr)) {
        let bounds = getDynamicBounds(pMin, pMax, false);
        setRangeBar("presRangeFill", "presCurrentMarker", pCurr, pMin, pMax, bounds.min, bounds.max);
    }

    // Wind Speed (Fixed Zero)
    let wMin = data.hasOwnProperty('windMin') ? parseFloat(data.windMin) : parseFloat(document.getElementById('windMin').innerText);
    let wMax = data.hasOwnProperty('windMax') ? parseFloat(data.windMax) : parseFloat(document.getElementById('windMax').innerText);
    let wCurr = data.hasOwnProperty('windspeedKmH') ? parseFloat(data.windspeedKmH) : currentWindSpeed;

    if (!isNaN(wCurr)) updateElement('windspeedKmH_Rec', wCurr, 1);

    if (!isNaN(wMin) && !isNaN(wMax) && !isNaN(wCurr)) {
        let bounds = getDynamicBounds(wMin, wMax, true);
        setRangeBar("windRangeFill", "windCurrentMarker", wCurr, wMin, wMax, bounds.min, bounds.max);
    }

    // Wind Gust (Fixed Zero)
    let wgMin = data.hasOwnProperty('windGMin') ? parseFloat(data.windGMin) : parseFloat(document.getElementById('windGMin').innerText);
    let wgMax = data.hasOwnProperty('windGMax') ? parseFloat(data.windGMax) : parseFloat(document.getElementById('windGMax').innerText);
    let wgCurr = data.hasOwnProperty('windgustKmH') ? parseFloat(data.windgustKmH) : 0;

    if (!isNaN(wgCurr)) updateElement('windgustKmH_Rec', wgCurr, 1);

    if (!isNaN(wgMin) && !isNaN(wgMax)) {
        let bounds = getDynamicBounds(wgMin, wgMax, true);
        setRangeBar("windGustRangeFill", "windGustCurrentMarker", wgCurr, wgMin, wgMax, bounds.min, bounds.max);
    }

    // Rain Rate (Simple bar, no range, but scale based on max)
    let rCurr = data.hasOwnProperty('rainHourMM') ? parseFloat(data.rainHourMM) : currentRainHour;
    let rMax = data.hasOwnProperty('rainPHMax') ? parseFloat(data.rainPHMax) : parseFloat(document.getElementById('rainPHMax').innerText);
    let rTotal = data.hasOwnProperty('dailyrainMM') ? parseFloat(data.dailyrainMM) : parseFloat(document.getElementById('dailyrainMM').innerText);

    if (!isNaN(rCurr)) updateElement('rainHourMM_Rec', rCurr, 1);
    // Populate the new Total Rain footer element in the Daily Records section
    if (!isNaN(rTotal)) updateElement('dailyrainMM_Rec', rTotal, 1);

    if (!isNaN(rCurr)) {
        // If we have a daily max Rain Rate, use that * 1.5 as scale. Default to 20mm/hr if no max or max is 0.
        let effectiveMax = (isNaN(rMax) || rMax === 0) ? 20 : rMax * 1.5;

        let pct = (rCurr / effectiveMax) * 100;
        pct = Math.min(100, Math.max(0, pct));
        const el = document.getElementById("rainRateFill");
        if (el) {
            el.style.width = pct + "%";
        }
    }
}

function getDynamicBounds(min, max, fixedZero) {
    if (fixedZero) {
        // For wind/rain, min is always 0. Scale max is Max * 1.5
        // If max is 0 (no wind yet), default scale to 50 km/h or similar so bar isn't empty.
        let upper = max > 0 ? max * 1.5 : 20;
        return { min: 0, max: upper };
    } else {
        // Dynamic centered range
        let span = max - min;
        // If span is 0 (min == max), add arbitrary padding (e.g. +/- 5 degrees/hPa)
        let padding = (span === 0) ? 5 : span * 0.25;
        // Total span becomes 1.5x original
        return { min: min - padding, max: max + padding };
    }
}

function setRangeBar(fillId, markerId, current, min, max, scaleMin, scaleMax) {
    const fillEl = document.getElementById(fillId);
    const markerEl = document.getElementById(markerId);
    if (!fillEl || !markerEl) return;

    // Safety checks for scale
    if (scaleMax <= scaleMin) {
        scaleMax = scaleMin + 1;
    }

    // Clamp values to scale
    let c = Math.max(scaleMin, Math.min(scaleMax, current));
    let mn = Math.max(scaleMin, Math.min(scaleMax, min));
    let mx = Math.max(scaleMin, Math.min(scaleMax, max));

    // Calculate percentages
    let rangeSpan = scaleMax - scaleMin;
    let leftPct = ((mn - scaleMin) / rangeSpan) * 100;
    let widthPct = ((mx - mn) / rangeSpan) * 100;
    let currPct = ((c - scaleMin) / rangeSpan) * 100;

    // Apply styles
    fillEl.style.left = leftPct + "%";
    fillEl.style.width = widthPct + "%";
    markerEl.style.left = currPct + "%";
}

function initializeAllHistoricalSVGCharts() {
    // Default to 10 minutes per point for initial chart setup, representing 24 hours.
    // This will be overridden by actual data from the server.
    const defaultMinutesPerPoint = 10;
    const defaultDisplayHours = 24;
    const defaultMillisPerChartPoint = defaultMinutesPerPoint * 60 * 1000;

    historicalTempSVGChartObject = createHistoricalSVGChart(
        "historicalTempSVGChartContainer",
        () => new Array(HISTORICAL_CHART_POINTS).fill(null).map((_, i) => [Date.now() - (HISTORICAL_CHART_POINTS - 1 - i) * defaultMillisPerChartPoint, null]), // Initial empty 144 points
        0,  // initialYMin (will be auto-adjusted)
        30, // initialYMax (will be auto-adjusted)
        "°C",
        "Temperature (" + defaultDisplayHours + "h)"
    );
    historicalHumSVGChartObject = createHistoricalSVGChart(
        "historicalHumSVGChartContainer",
        () => new Array(HISTORICAL_CHART_POINTS).fill(null).map((_, i) => [Date.now() - (HISTORICAL_CHART_POINTS - 1 - i) * defaultMillisPerChartPoint, null]),
        0,  // initialYMin
        100, // initialYMax
        "%rH",
        "Humidity (" + defaultDisplayHours + "h)"
    );
    historicalPresSVGChartObject = createHistoricalSVGChart(
        "historicalPresSVGChartContainer",
        () => new Array(HISTORICAL_CHART_POINTS).fill(null).map((_, i) => [Date.now() - (HISTORICAL_CHART_POINTS - 1 - i) * defaultMillisPerChartPoint, null]),
        950,  // initialYMin
        1050, // initialYMax
        "hPa",
        "Air Pressure (" + defaultDisplayHours + "h)"
    );
    historicalWindSVGChartObject = createHistoricalSVGChart(
        "historicalWindSVGChartContainer",
        () => new Array(HISTORICAL_CHART_POINTS).fill(null).map((_, i) => [Date.now() - (HISTORICAL_CHART_POINTS - 1 - i) * defaultMillisPerChartPoint, null]),
        0,  // initialYMin
        50, // initialYMax (adjust as needed for typical wind speeds)
        "km/h",
        "Wind Speed (" + defaultDisplayHours + "h)"
    );

    historicalRainSVGChartObject = createHistoricalSVGChart(
        "historicalRainVGChartContainer",
        () => new Array(HISTORICAL_CHART_POINTS).fill(null).map((_, i) => [Date.now() - (HISTORICAL_CHART_POINTS - 1 - i) * defaultMillisPerChartPoint, null]),
        0,  // initialYMin
        10, // initialYMax (adjust as needed for typical rain)
        "mm",
        "Rainfall (" + defaultDisplayHours + "h)"
    );

    historicalBattVoltSVGChartObject = createHistoricalSVGChart(
        "historicalBattVoltVGChartContainer",
        () => new Array(HISTORICAL_CHART_POINTS).fill(null).map((_, i) => [Date.now() - (HISTORICAL_CHART_POINTS - 1 - i) * defaultMillisPerChartPoint, null]),
        3.0,  // initialYMin
        4.3, // initialYMax
        "V",
        "Battery Voltage (24h)",
        2  // Set decimal precision to 2
    );
}

function requestFullHistory() { // This function is currently not called by the client, server sends on connect
    if (websocket && websocket.readyState === WebSocket.OPEN) {
        receivedHourlyChunks = 0;
        fullDayData = new Array(24).fill(null).map(EMPTY_HOUR_DATA);
        websocket.send("requestFullHistory");
        console.log("Requested full historical data.");
    } else {
        console.log("WebSocket not open. Cannot request history.");
    }
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function handleGlobalChartResize() {
    activeChartsForResize.forEach(chartInstanceOrObject => {
        if (chartInstanceOrObject && typeof chartInstanceOrObject.redrawChartStructure === 'function') {
            // This will call redrawChartStructure for both mini-charts and the new historical SVG chart
            // as they will share this method name.
            chartInstanceOrObject.redrawChartStructure();
        }
    });
}
window.addEventListener('resize', debounce(handleGlobalChartResize, 250));

function initWindRoseSVG() {
    console.log("Initializing Wind Rose SVG...");
    const roseGroup = document.getElementById("wind-rose");
    if (!roseGroup) {
        console.error("Wind rose group not found in DOM!");
        return;
    }

    roseGroup.innerHTML = "";
    for (let i = 0; i < 16; i++) {
        const petal = document.createElementNS("http://www.w3.org/2000/svg", "path");
        petal.setAttribute("id", `rose-petal-${i}`);
        petal.setAttribute("class", "wind-rose-petal");
        petal.setAttribute("d", "M 0 0 L 0 0 L 0 0 Z");
        roseGroup.appendChild(petal);
    }
}

function updateWindRose(windDirData) {
    if (!windDirData || !Array.isArray(windDirData)) {
        console.warn("updateWindRose called with invalid data:", windDirData);
        return;
    }


    // Filter out nulls and normalize to number
    const validDirs = windDirData
        .map(d => parseFloat(d))
        .filter(d => !isNaN(d) && d !== -1);

    if (validDirs.length === 0) {
        console.warn("No valid direction data points for Wind Rose.");
        return;
    }

    // 16 bins (22.5 degrees each)
    const bins = new Array(16).fill(0);
    validDirs.forEach(dir => {
        // Map 0-360 to 0-15, centered on cardinal points (N, NNE, NE, etc.)
        // N is 0, so N bin is -11.25 to 11.25
        let binIdx = Math.floor(((dir + 11.25) % 360) / 22.5);
        bins[binIdx]++;
    });

    const maxCount = Math.max(...bins);
    if (maxCount === 0) return;

    const maxRadius = 85; // Give some buffer inside the 100px radius dial

    bins.forEach((count, i) => {
        const petal = document.getElementById(`rose-petal-${i}`);
        if (!petal) return;

        // Radius proportional to frequency (or use sqrt for area-proportional if preferred, 
        // but linear frequency is common for roses)
        const radius = (count / maxCount) * maxRadius;
        
        if (radius === 0) {
            petal.setAttribute("d", "M 0 0 L 0 0 L 0 0 Z");
            return;
        }

        const angle = i * 22.5; // Center of the bin
        const startAngle = (angle - 10) * (Math.PI / 180); // Slightly narrower than the bin for gap
        const endAngle = (angle + 10) * (Math.PI / 180);

        // Calculate points (SVG Y is inverted)
        const x1 = Math.sin(startAngle) * radius;
        const y1 = -Math.cos(startAngle) * radius;
        const x2 = Math.sin(endAngle) * radius;
        const y2 = -Math.cos(endAngle) * radius;

        // Create a pleasant curved petal or a simple segment
        // Let's use a simple triangle for now, it looks clean
        petal.setAttribute("d", `M 0 0 L ${x1.toFixed(2)} ${y1.toFixed(2)} L ${x2.toFixed(2)} ${y2.toFixed(2)} Z`);
    });
    console.log("Wind Rose update complete.");
}

function initializeAllMiniCharts() {
    miniChartInstances["tempChart"] = createMiniChart("tempChart", () => currentTemperature, 0, 40, "°C");
    miniChartInstances["humidityChart"] = createMiniChart("humidityChart", () => currentHumidity, 0, 100, "%");
    miniChartInstances["pressureChart"] = createMiniChart("pressureChart", () => currentPressure, 950, 1050, "hPa");
    miniChartInstances["windSpeedChart"] = createMiniChart("windSpeedChart", () => currentWindSpeed, 0, 30, "km/h");
    miniChartInstances["rainChart"] = createMiniChart("rainChart", () => currentRainHour, 0, 10, "mm/hr", "column");
}

// Added a new parameter for title and decimalPlaces to createHistoricalSVGChart
function createHistoricalSVGChart(chartElementId, dataSourceGetter, initialYMin, initialYMax, unit = "", title = "", decimalPlaces = 1) {
    const chartElement = document.getElementById(chartElementId);
    if (!chartElement) {
        console.error(`Historical SVG Chart element with ID ${chartElementId} not found.`);
        return null;
    }

    const dataPoints = HISTORICAL_CHART_POINTS; // Now 144 points
    let chartHeight = 300; // Default height, can be overridden by CSS
    let chartWidth = 600;  // Default width, can be overridden by CSS

    const yAxisLabelPadding = 45; // Padding on the left for Y-axis labels
    const xAxisLabelPadding = 40; // Padding at the bottom for X-axis labels
    const chartPaddingTop = 30;    // Space for title
    const chartPaddingRight = 15; // Padding on the right of the plot area
    // chartPaddingBottom is effectively handled by xAxisLabelPadding for the overall SVG bottom space

    let drawablePlotWidth, drawablePlotHeight, xScale, windIndicatorRowHeight = 20; // Renamed for clarity
    let yMinVal = initialYMin;
    let yMaxVal = initialYMax;

    // This will store [timestamp, value] pairs
    let currentChartData = dataSourceGetter(); // dataSourceGetter now provides initial 144 [ts, null] pairs

    let currentTitle = title; // Store the current title

    function mapNumber(value, in_min, in_max, out_min, out_max) {
        // This function now handles the wind direction indicator row height
        out_max = out_max - (chartElementId === "historicalWindSVGChartContainer" ? windIndicatorRowHeight : 0);
        if (in_max === in_min) return out_min; // Avoid division by zero
        if (value === null || value === undefined) return out_max; // Plot nulls at the bottom or handle as needed
        return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    }

    // Helper to get wind indicator color based on speed
    function getWindSpeedColor(speed, maxSpeed) {
        const isDarkMode = document.body.classList.contains('dark-mode');
        // Define color stops for the gradient
        const colorStops = [
            { speed: 0, color: isDarkMode ? '#5c9ce6' : '#007bff' }, // Light Blue / Blue
            { speed: maxSpeed * 0.25, color: isDarkMode ? '#3b5998' : '#0056b3' }, // Navy
            { speed: maxSpeed * 0.6, color: isDarkMode ? '#e65c5c' : '#dc3545' }, // Red
            { speed: maxSpeed, color: isDarkMode ? '#f8f9fa' : '#000000' }  // White / Black
        ];

        if (speed <= 0) return colorStops[0].color;

        for (let i = 1; i < colorStops.length; i++) {
            if (speed <= colorStops[i].speed) {
                const lower = colorStops[i - 1];
                const upper = colorStops[i];
                const range = upper.speed - lower.speed;
                const pos = (speed - lower.speed) / range;

                // Simple linear interpolation for RGB values
                const r1 = parseInt(lower.color.substring(1, 3), 16);
                const g1 = parseInt(lower.color.substring(3, 5), 16);
                const b1 = parseInt(lower.color.substring(5, 7), 16);
                const r2 = parseInt(upper.color.substring(1, 3), 16);
                const g2 = parseInt(upper.color.substring(3, 5), 16);
                const b2 = parseInt(upper.color.substring(5, 7), 16);

                const r = Math.round(r1 + pos * (r2 - r1)).toString(16).padStart(2, '0');
                const g = Math.round(g1 + pos * (g2 - g1)).toString(16).padStart(2, '0');
                const b = Math.round(b1 + pos * (b2 - b1)).toString(16).padStart(2, '0');
                return `#${r}${g}${b}`;
            }
        }
        return colorStops[colorStops.length - 1].color; // Return max color if speed is > max
    }

    function renderSVG() {
        const isDarkMode = document.body.classList.contains('dark-mode');
        const colors = {
            bg: isDarkMode ? '#2e3338' : '#ffffff',
            axisLines: isDarkMode ? '#adb5bd' : '#cccccc',
            textFill: isDarkMode ? '#f8f9fa' : '#333333',
            dataPathStroke: isDarkMode ? '#4dabf7' : '#007bff',
            gustMarkerFill: isDarkMode ? '#fcc419' : '#ff922b',
            titleFill: isDarkMode ? '#f8f9fa' : '#333333'
        };

        // Filter out null data for y-axis scaling, but keep nulls for plotting gaps
        let allValuesForScaling = currentChartData.map(p => p[1]);
        if (chartObject.isWindChart && chartObject.gustData) { // Only consider gust data for wind chart
            allValuesForScaling.push(...chartObject.gustData.map(p => p[1]));
        }
        const validDataValues = allValuesForScaling.filter(val => val !== null && !isNaN(parseFloat(val)));

        let calculatedMin = validDataValues.length > 0 ? Math.min(...validDataValues) : initialYMin;

        // Force 0 start for Wind and Rain charts
        if (chartObject.isWindChart || (typeof chartElementId === 'string' && chartElementId.includes("Rain"))) {
            calculatedMin = Math.min(0, calculatedMin);
        }

        yMinVal = calculatedMin;
        yMaxVal = validDataValues.length > 0 ? Math.max(...validDataValues) : initialYMax;

        // Ensure yMaxVal is always greater than yMinVal for scaling
        if (yMaxVal <= yMinVal) {
            yMaxVal = yMinVal + (initialYMax > initialYMin ? (initialYMax - initialYMin) * 0.1 : 1); // Add a small default range
        }
        // Add some padding to y-axis
        const yRange = yMaxVal - yMinVal;
        yMinVal -= yRange * 0.05;
        yMaxVal += yRange * 0.05;
        if (yMaxVal <= yMinVal) yMaxVal = yMinVal + 1; // Final fallback


        let out = `<svg xmlns="http://www.w3.org/2000/svg" version="1.1" font-family="Arial, Helvetica, sans-serif" width="${chartWidth}" height="${chartHeight}" style="background-color:${colors.bg};">`;

        // Title
        if (currentTitle) { // Use currentTitle
            out += `<text x="${chartWidth / 2}" y="${chartPaddingTop / 2 + 5}" font-size="16px" fill="${colors.titleFill}" text-anchor="middle" dominant-baseline="middle">${title}</text>`;
        }

        // Plot area translation
        out += `<g transform="translate(${yAxisLabelPadding}, ${chartPaddingTop})">`;

        // Y-Axis line and X-Axis line
        out += `<line x1="0" y1="0" x2="0" y2="${drawablePlotHeight}" style="stroke:${colors.axisLines};stroke-width:1" />`; // Y-axis line
        out += `<line x1="0" y1="${drawablePlotHeight}" x2="${drawablePlotWidth}" y2="${drawablePlotHeight}" style="stroke:${colors.axisLines};stroke-width:1" />`; // X-axis line

        // Y-Axis labels and ticks (example: 5 ticks)
        const numYTicks = 5;
        for (let i = 0; i <= numYTicks; i++) {
            const val = yMinVal + (i * (yMaxVal - yMinVal) / numYTicks);
            const yPos = drawablePlotHeight - mapNumber(val, yMinVal, yMaxVal, 0, drawablePlotHeight);
            out += `<text x="-5" y="${yPos}" font-size="10px" fill="${colors.textFill}" text-anchor="end" dominant-baseline="middle">${val.toFixed(decimalPlaces)}</text>`;
            out += `<line x1="0" y1="${yPos}" x2="-3" y2="${yPos}" style="stroke:${colors.axisLines};stroke-width:1" />`;
        }
        if (unit) {
            out += `<text x="${-(yAxisLabelPadding * 0.65)}" y="${drawablePlotHeight / 2}" font-size="12px" fill="${colors.textFill}" text-anchor="middle" dominant-baseline="central" transform="rotate(-90, ${-(yAxisLabelPadding * 0.65)}, ${drawablePlotHeight / 2})">${unit}</text>`;
        }


        // X-Axis labels and ticks: Smart alignment to hour boundaries
        const startTs = currentChartData[0][0];
        const endTs = currentChartData[dataPoints - 1][0];
        const totalDurationMs = endTs - startTs;
        const totalHours = totalDurationMs / 3600000;

        // Determine a "nice" label interval (in hours)
        let intervalHours = 4;
        if (totalHours <= 3) intervalHours = 0.5;
        else if (totalHours <= 6) intervalHours = 1;
        else if (totalHours <= 12) intervalHours = 2;
        else intervalHours = 4;

        const intervalMs = intervalHours * 3600000;

        // Find the first label position (aligned to interval)
        // We want the labels to be at e.g. 00:00, 04:00, 08:00 etc.
        let firstLabelTs = Math.ceil(startTs / intervalMs) * intervalMs;

        for (let t = firstLabelTs; t <= endTs; t += intervalMs) {
            const ratio = (t - startTs) / totalDurationMs;
            if (ratio < 0 || ratio > 1) continue;

            const xPos = ratio * drawablePlotWidth;
            const tickDate = new Date(t);
            const timeLabel = `${String(tickDate.getHours()).padStart(2, '0')}:${String(tickDate.getMinutes()).padStart(2, '0')}`;

            out += `<text x="${xPos}" y="${drawablePlotHeight + 20}" font-size="10px" fill="${colors.textFill}" text-anchor="middle">${timeLabel}</text>`;
            out += `<line x1="${xPos}" y1="${drawablePlotHeight}" x2="${xPos}" y2="${drawablePlotHeight + 4}" style="stroke:${colors.axisLines};stroke-width:1" />`;
        }

        // Data path
        let pathData = "";
        let firstPoint = true;
        for (let i = 0; i < dataPoints; i++) {
            if (currentChartData && currentChartData[i] && currentChartData[i][1] !== null) {
                let xPos = i * xScale; // xScale is (drawablePlotWidth / (dataPoints - 1))
                let yPos = drawablePlotHeight - mapNumber(currentChartData[i][1], yMinVal, yMaxVal, 0, drawablePlotHeight);
                if (firstPoint) {
                    pathData += `M ${xPos.toFixed(2)} ${yPos.toFixed(2)}`;
                    firstPoint = false;
                } else {
                    pathData += ` L ${xPos.toFixed(2)} ${yPos.toFixed(2)}`;
                }
            } else {
                firstPoint = true; // Start new path segment after a null
            }
        }
        if (pathData) {
            let pathStyle;
            if (chartObject.isWindChart) {
                // Use a dashed line style for the wind speed average
                pathStyle = `fill:none;stroke:${colors.dataPathStroke};stroke-width:1.0;stroke-dasharray: 3, 3;`;
            } else {
                // Use a solid, slightly thicker line for other charts
                pathStyle = `fill:none;stroke:${colors.dataPathStroke};stroke-width:1.5;`;
            }
            out += `<path d="${pathData}" style="${pathStyle}" />`;
        }

        // Wind Gust Markers (only for the wind chart)
        if (chartObject.isWindChart && chartObject.gustData) {
            for (let i = 0; i < dataPoints; i++) {
                if (chartObject.gustData[i] && chartObject.gustData[i][1] !== null) {
                    let xPos = i * xScale;
                    let yPos = drawablePlotHeight - mapNumber(chartObject.gustData[i][1], yMinVal, yMaxVal, 0, drawablePlotHeight); // Map gust value to Y position
                    out += `<circle cx="${xPos.toFixed(2)}" cy="${yPos.toFixed(2)}" r="2" fill="${colors.gustMarkerFill}" />`;
                }
            }
        }

        // Wind Direction Indicators (only for the wind chart)
        if (chartObject.isWindChart && chartObject.dirData) {
            for (let i = 0; i < dataPoints; i++) {
                // Reduce clutter: Only draw every 2nd indicator
                if (i % 2 !== 0) continue;

                // Check if there is valid direction AND speed data for this point
                if (chartObject.dirData[i] && chartObject.dirData[i][1] !== null &&
                    currentChartData[i] && currentChartData[i][1] !== null) {

                    const windSpeed = currentChartData[i][1];
                    const xPos = i * xScale;
                    // Calculate the y-position based on the wind speed data point
                    const yPos = drawablePlotHeight - mapNumber(windSpeed, yMinVal, yMaxVal, 0, drawablePlotHeight);
                    const angle = chartObject.dirData[i][1];

                    // --- Calculate size and color based on wind speed ---
                    const maxChartSpeed = yMaxVal > 0 ? yMaxVal : 50; // Use chart's max Y, or 50 as a fallback
                    // Scale Size: Make it start larger and grow faster (saturate at 80% of max speed)
                    // Range increased to 8px - 48px
                    let speedForSize = windSpeed;
                    if (speedForSize > maxChartSpeed * 0.8) speedForSize = maxChartSpeed * 0.8;

                    const indicatorSize = mapNumber(speedForSize, 0, maxChartSpeed * 0.8, 8, 48);
                    const indicatorColor = getWindSpeedColor(windSpeed, maxChartSpeed);
                    const length = indicatorSize; // The length of the triangle
                    const width = length / 3; // Width is one-third of the length

                    // A simple triangle path. 'M -4,4 L 4,4 L 0,-4 Z' defines a triangle pointing up.
                    // We translate and rotate it into position.
                    // Add 180 degrees to the angle to make the indicator point *from* the wind direction.
                    out += `<g transform="translate(${xPos.toFixed(2)}, ${yPos.toFixed(2)}) rotate(${angle + 180})">`;
                    out += `<path d="M -${width / 2},${length / 2} L ${width / 2},${length / 2} L 0,-${length / 2} Z" fill="${indicatorColor}" />`;
                    out += `</g>`;
                }
            }
        }

        out += `</g>`; // End plot area transform
        out += `</svg>`;
        chartElement.innerHTML = out;

        // --- Add interactive Tooltips via DOM ---
        const svg = chartElement.querySelector('svg');
        // isDarkMode is already defined in renderSVG scope

        // Tooltip Group
        let tooltipGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
        tooltipGroup.setAttribute("visibility", "hidden");
        // No pointer-events:none here, we want it to be above? No, the capture zones are fixed.
        // Actually, we want the tooltip to NOT interfere with mouse events if it overlaps? 
        tooltipGroup.setAttribute("pointer-events", "none");

        let tooltipBg = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        tooltipBg.setAttribute("fill", isDarkMode ? "rgba(40, 44, 52, 0.95)" : "rgba(255, 255, 255, 0.95)");
        tooltipBg.setAttribute("stroke", isDarkMode ? "#6c757d" : "#dee2e6");
        tooltipBg.setAttribute("stroke-width", "1");
        tooltipBg.setAttribute("rx", "4");
        tooltipBg.setAttribute("ry", "4");
        tooltipBg.setAttribute("filter", "drop-shadow(0 2px 4px rgba(0,0,0,0.2))");

        let tooltipText = document.createElementNS("http://www.w3.org/2000/svg", "text");
        tooltipText.setAttribute("fill", isDarkMode ? "#f8f9fa" : "#212529");
        tooltipText.setAttribute("font-size", "12px");
        tooltipText.setAttribute("text-anchor", "middle");
        tooltipText.setAttribute("font-family", "Arial, sans-serif"); // Match chart font

        let tooltipVal = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
        tooltipVal.setAttribute("x", "0");
        tooltipVal.setAttribute("dy", "1.2em");
        tooltipVal.setAttribute("font-weight", "bold");

        let tooltipTime = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
        tooltipTime.setAttribute("x", "0");
        tooltipTime.setAttribute("dy", "1.2em");
        tooltipTime.setAttribute("font-size", "11px");
        tooltipTime.setAttribute("fill", isDarkMode ? "#adb5bd" : "#6c757d");

        tooltipText.appendChild(tooltipVal);
        tooltipText.appendChild(tooltipTime);
        tooltipGroup.appendChild(tooltipBg);
        tooltipGroup.appendChild(tooltipText);

        // Capture Zones Group (to keep DOM clean)
        let captureGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
        // Apply the same transform as the plot area to align coordinates easily
        // plot area transform was: translate(${yAxisLabelPadding}, ${chartPaddingTop})
        captureGroup.setAttribute("transform", `translate(${yAxisLabelPadding}, ${chartPaddingTop})`);

        const sliceWidth = drawablePlotWidth / (HISTORICAL_CHART_POINTS - 1);

        currentChartData.forEach((p, index) => {
            // We create a zone for every point to ensure continuous hover coverage
            if (p[0] === null) return; // No timestamp? skip

            const val = p[1];
            const xCenter = index * xScale;

            // Determine Y anchor for tooltip (closest data point)
            let dataY = (val !== null) ? val : yMinVal; // default to bottom if null
            if (chartObject.isWindChart && chartObject.gustData && chartObject.gustData[index][1] !== null) {
                // Prefer gust height if higher? Or just main wind? Let's use max of them to keep it visible
                if (val !== null) dataY = Math.max(val, chartObject.gustData[index][1]);
                else dataY = chartObject.gustData[index][1];
            }

            // Map Y to pixels
            // mapNumber logic: (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
            // In render loop, out_min = drawablePlotHeight, out_max = 0 (SVG coords)
            // But wait, standard SVG Y is 0 at top. 
            // In the 'out+=' string logic, the transform was applied. 
            // Here we are inside the transform group `captureGroup`.
            // So 0,0 is top-left of plot area.
            // min value -> height (bottom), max value -> 0 (top)
            const mappedY = (dataY - yMinVal) * (0 - drawablePlotHeight) / (yMaxVal - yMinVal) + drawablePlotHeight;

            let captureZone = document.createElementNS("http://www.w3.org/2000/svg", "rect");
            captureZone.setAttribute("x", xCenter - (sliceWidth / 2));
            captureZone.setAttribute("y", 0);
            captureZone.setAttribute("width", sliceWidth);
            captureZone.setAttribute("height", drawablePlotHeight);
            captureZone.setAttribute("fill", "transparent");
            // captureZone.setAttribute("stroke", "cyan"); captureZone.setAttribute("opacity", "0.2"); // Debug

            captureZone.addEventListener("mouseenter", (e) => {
                let valStr = "";
                if (val !== null) valStr = val.toFixed(decimalPlaces) + unit;

                // Wind specific
                if (chartObject.isWindChart && chartObject.gustData && chartObject.gustData[index][1] !== null) {
                    if (valStr) valStr += " | ";
                    valStr += "G: " + chartObject.gustData[index][1].toFixed(1);
                } else if (val === null) {
                    valStr = "--";
                }

                const dateObj = new Date(p[0]);
                const timeStr = dateObj.getHours().toString().padStart(2, '0') + ":" + dateObj.getMinutes().toString().padStart(2, '0');

                tooltipVal.textContent = valStr;
                tooltipTime.textContent = timeStr;

                // Calculate sizes
                const bb = tooltipText.getBBox ? tooltipText.getBBox() : { width: 80, height: 35 };
                const bgW = bb.width + 16;
                const bgH = bb.height + 10;

                // Calculate Position (in global SVG coords)
                // captureGroup is translated by (yAxisLabelPadding, chartPaddingTop)
                // xCenter is relative to that.
                let globalX = yAxisLabelPadding + xCenter;
                let globalY = chartPaddingTop + mappedY - bgH - 10;

                // Boundary checks
                if (globalX < bgW / 2) globalX = bgW / 2 + 5;
                if (globalX > chartWidth - bgW / 2) globalX = chartWidth - bgW / 2 - 5;
                if (globalY < 10) globalY = chartPaddingTop + mappedY + 20; // Flip to bottom

                tooltipBg.setAttribute("width", bgW);
                tooltipBg.setAttribute("height", bgH);
                tooltipBg.setAttribute("x", -bgW / 2);
                tooltipBg.setAttribute("y", -bgH / 2 + 3); // Center adjustment

                tooltipGroup.setAttribute("transform", `translate(${globalX}, ${globalY})`);
                tooltipGroup.setAttribute("visibility", "visible");
            });

            captureZone.addEventListener("mouseleave", () => {
                tooltipGroup.setAttribute("visibility", "hidden");
            });

            captureGroup.appendChild(captureZone);
        });

        // Append groups: Capture first (so it's on top of lines?), Tooltip last (on top of everything)
        // Actually capture rects describe the interaction area. They are transparent. 
        // We want them on top of the plot area contents so they grab events.
        svg.appendChild(captureGroup);
        svg.appendChild(tooltipGroup);
    }

    function redrawChartStructure() {
        chartWidth = chartElement.clientWidth || 600;
        chartHeight = chartElement.clientHeight || 300;
        if (chartWidth < 100) chartWidth = 100;
        if (chartHeight < 100) chartHeight = 100;

        drawablePlotWidth = chartWidth - yAxisLabelPadding - chartPaddingRight;
        const bottomPadding = xAxisLabelPadding; // No longer need extra space for wind indicators
        drawablePlotHeight = chartHeight - chartPaddingTop - bottomPadding;

        xScale = drawablePlotWidth / (dataPoints > 1 ? dataPoints - 1 : 1);
        renderSVG();
    }

    function updateFullData(newDataArray, newGustData = null, newDirData = null) { // Added default nulls for new params
        if (newDataArray && newDataArray.length === dataPoints) {
            currentChartData = newDataArray;
            if (chartObject.isWindChart && newGustData && newDirData) { // Only update if it's the wind chart and data is provided
                chartObject.gustData = newGustData;
                chartObject.dirData = newDirData;
            }
        } else {
            console.warn("updateFullData received invalid data or length mismatch. Expected " + dataPoints + " points.");
            // Fallback to empty data if needed
            currentChartData = new Array(dataPoints).fill(null).map((_, i) => [Date.now() - (dataPoints - 1 - i) * 60000, null]);
        }
        redrawChartStructure();
    }

    function updateTitle(newTitle) {
        currentTitle = newTitle;
        redrawChartStructure(); // Redraw to update the title
    }

    // addLatestPoint is removed as this chart will update with full 10-min average datasets
    // function addLatestPoint(timestamp, value) { ... } 

    const chartObject = {
        redrawChartStructure: redrawChartStructure,
        updateFullData: updateFullData, // Method to update with a full new dataset
        updateTitle: updateTitle, // New method to update the chart title
        isMiniChart: false, // Differentiate from mini charts (this is a historical chart)
        isHistoricalSVG: true,
        isWindChart: chartElementId === "historicalWindSVGChartContainer",
        gustData: null, // Will hold gust data for the wind chart
        dirData: null   // Will hold direction data for the wind chart
    };

    activeChartsForResize.push(chartObject);
    redrawChartStructure(); // Initial draw
    return chartObject;
}


function createMiniChart(chartElementId, dataSourceGetter, initialYMin, initialYMax, unit = "", chartType = "line") {
    const chartElement = document.getElementById(chartElementId);
    if (!chartElement) {
        console.error(`Chart element with ID ${chartElementId} not found.`);
        return null;
    }

    const dataPoints = 300;
    let chartHeight = 100;
    let chartWidth = 150;
    const yAxisLabelPadding = 12;
    const chartPadding = 5;
    let plotAreaWidth, plotAreaHeight, yMaxGraphHeight, xScale;
    let yMinVal = initialYMin;
    let yMaxVal = initialYMax;
    let sensorValueArray = new Array(dataPoints).fill(null);
    const Y1Array = new Array(dataPoints).fill(0);

    function mapNumber(value, in_min, in_max, out_min, out_max) {
        if (in_max === in_min) return out_min;
        return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    }

    function miniChartSVG() {
        const isDarkMode = document.body.classList.contains('dark-mode');
        const colors = {
            yAxisAreaBg: 'transparent', plotAreaBg: 'transparent',
            axisLines: isDarkMode ? '#adb5bd' : '#000000',
            textFill: isDarkMode ? '#f8f9fa' : '#000000',
            dataPathStroke: isDarkMode ? '#4dabf7' : '#007bff',
            currentValueFill: isDarkMode ? '#4dabf7' : 'blue'
        };
        let out = `<svg xmlns="http://www.w3.org/2000/svg" version="1.1" font-family="Arial, Helvetica, sans-serif" width="${chartWidth}" height="${chartHeight}">`;
        out += `<rect x="0" y="0" width="${yAxisLabelPadding}" height="${chartHeight}" fill="${colors.yAxisAreaBg}" />`;
        out += `<rect x="${yAxisLabelPadding}" y="0" width="${plotAreaWidth}" height="${plotAreaHeight}" fill="${colors.plotAreaBg}" />`;
        out += `<g transform="translate(${yAxisLabelPadding}, 0)">`;
        out += `<line x1="0" y1="0" x2="0" y2="${plotAreaHeight}" style="stroke:${colors.axisLines};stroke-width:1" />`;
        out += `<line x1="0" y1="${plotAreaHeight - chartPadding}" x2="${plotAreaWidth}" y2="${plotAreaHeight - chartPadding}" style="stroke:${colors.axisLines};stroke-width:1" />`;
        out += `<text x="2" y="${chartPadding + 3}" font-size="10px" fill="${colors.textFill}" dominant-baseline="hanging">${yMaxVal.toFixed(1)}</text>`;
        out += `<text x="2" y="${chartHeight - chartPadding}" font-size="10px" fill="${colors.textFill}" dominant-baseline="alphabetic">${yMinVal.toFixed(1)}</text>`;
        if (unit) {
            out += `<text x="8" y="${chartHeight / 2}" font-size="10px" fill="${colors.textFill}" text-anchor="middle" dominant-baseline="central" transform="rotate(-90, 8, ${chartHeight / 2})">${unit}</text>`;
        }
        const numTicks = 5;
        for (let i = 0; i < numTicks; i++) {
            const tickY = chartPadding + (i * (yMaxGraphHeight / (numTicks - 1)));
            out += `<line x1="0" y1="${tickY}" x2="-4" y2="${tickY}" style="stroke:${colors.axisLines};stroke-width:1" />`;
        }
        const validValuesForText = sensorValueArray.filter(v => typeof v === 'number' && !isNaN(v));
        if (validValuesForText.length > 0) {
            let lastSensorVal = validValuesForText[validValuesForText.length - 1];
            let lastIdx = sensorValueArray.lastIndexOf(lastSensorVal);
            let lastMappedY = plotAreaHeight - chartPadding - Y1Array[lastIdx];
            lastMappedY = Math.max(chartPadding + 10, Math.min(plotAreaHeight - chartPadding - 2, lastMappedY));
            out += `<text x="${plotAreaWidth - 3}" y="${lastMappedY}" font-size="10px" fill="${colors.currentValueFill}" text-anchor="end" dominant-baseline="alphabetic">${lastSensorVal.toFixed(1)}</text>`;
        }

        if (chartType === "line") {
            let pathData = "";
            let firstPoint = true;
            for (let i = 0; i < dataPoints; i++) {
                const val = sensorValueArray[i];
                if (typeof val === 'number' && !isNaN(val)) {
                    const x = (i * xScale).toFixed(2);
                    const y = (plotAreaHeight - chartPadding - Y1Array[i]).toFixed(2);
                    if (firstPoint) {
                        pathData += `M ${x} ${y}`;
                        firstPoint = false;
                    } else {
                        pathData += ` L ${x} ${y}`;
                    }
                } else {
                    firstPoint = true; // Break path at data gap
                }
            }
            if (pathData) {
                out += `<path d="${pathData}" style="fill:none;stroke:${colors.dataPathStroke};stroke-width:1.5" />`;
            }
        } else if (chartType === "column") {
            const barWidth = Math.max(1, xScale * 0.8);
            const barPadding = xScale - barWidth;
            for (let i = 0; i < dataPoints; i++) {
                const val = sensorValueArray[i];
                if (typeof val === 'number' && !isNaN(val)) {
                    const barHeight = Y1Array[i];
                    if (barHeight > 0) {
                        out += `<rect x="${(i * xScale + barPadding / 2).toFixed(2)}" y="${(plotAreaHeight - chartPadding - barHeight).toFixed(2)}" width="${barWidth.toFixed(2)}" height="${barHeight.toFixed(2)}" fill="${colors.dataPathStroke}" />`;
                    }
                }
            }
        }
        out += `</g></svg>`;
        chartElement.innerHTML = out;
    }

    function redrawChartStructure() {
        chartWidth = chartElement.clientWidth || 150;
        chartHeight = chartElement.clientHeight || 100;
        if (chartWidth < 50) chartWidth = 50;
        if (chartHeight < 30) chartHeight = 30;
        plotAreaWidth = chartWidth - yAxisLabelPadding;
        plotAreaHeight = chartHeight;
        yMaxGraphHeight = chartHeight - (2 * chartPadding);
        xScale = plotAreaWidth / (dataPoints - 1);
        for (let i = 0; i < dataPoints; i++) {
            Y1Array[i] = mapNumber(sensorValueArray[i], yMinVal, yMaxVal, 0, yMaxGraphHeight);
        }
        miniChartSVG();
    }

    function updateChart() {
        let currentValue = dataSourceGetter();
        if (typeof currentValue !== 'number' || isNaN(currentValue)) {
            // Wait for initial data before advancing ticks
            return;
        }
        sensorValueArray.shift();
        sensorValueArray.push(currentValue);
        
        const validValues = sensorValueArray.filter(v => typeof v === 'number' && !isNaN(v));
        let currentDataMin = validValues.length > 0 ? Math.min(...validValues) : initialYMin;
        let currentDataMax = validValues.length > 0 ? Math.max(...validValues) : initialYMax;
        
        const range = currentDataMax - currentDataMin;
        const padding = Math.max(range * 0.1, (initialYMax - initialYMin) * 0.005, 0.1);
        yMinVal = currentDataMin - padding;
        yMaxVal = currentDataMax + padding;
        if (yMaxVal <= yMinVal) {
            yMaxVal = yMinVal + Math.max((initialYMax - initialYMin) * 0.01, 1);
        }
        for (let i = 0; i < dataPoints; i++) {
            Y1Array[i] = mapNumber(sensorValueArray[i], yMinVal, yMaxVal, 0, yMaxGraphHeight);
        }
        miniChartSVG();
    }
    
    function setHistory(newData) {
        if (!newData || newData.length !== dataPoints) return;
        sensorValueArray = [...newData]; // Copy new data
        // Reset min/max for the new data set
        yMinVal = Math.min(...sensorValueArray.filter(v => typeof v === 'number' && !isNaN(v)));
        yMaxVal = Math.max(...sensorValueArray.filter(v => typeof v === 'number' && !isNaN(v)));
        // Add padding
        const range = yMaxVal - yMinVal;
        const padding = Math.max(range * 0.1, (initialYMax - initialYMin) * 0.005, 0.1);
        yMinVal -= padding;
        yMaxVal += padding;
        if (yMaxVal <= yMinVal) yMaxVal = yMinVal + Math.max((initialYMax - initialYMin) * 0.01, 1);
        
        redrawChartStructure();
    }

    const chartObject = {
        redrawChartStructure: redrawChartStructure,
        setHistory: setHistory,
        isMiniChart: true
    }; // Removed isHistoricalSVG from mini-chart object
    activeChartsForResize.push(chartObject);
    redrawChartStructure();
    setInterval(updateChart, 1000);
    return chartObject;
}

document.addEventListener('DOMContentLoaded', () => {
    let allCheckboxes = document.querySelectorAll('input[type=checkbox]');
    allCheckboxes.forEach(checkbox => checkbox.addEventListener("change", updateToggle));

    let allTimeInputs = document.querySelectorAll('input[type=time]');
    allTimeInputs.forEach(input => input.addEventListener("change", updateTimeInput));

    let allNumberInputs = document.querySelectorAll('input[type=number]');
    allNumberInputs.forEach(input => input.addEventListener("change", sendForm));

    let allDropDownInputs = document.querySelectorAll('select');
    allDropDownInputs.forEach(select => select.addEventListener("change", getDropdown));
});

// --- Event listener attachment functions ---
// These functions are called from the HTML onchange attributes.
// It's generally better to attach listeners via JavaScript (as done above in DOMContentLoaded),
// but if you keep onchange in HTML, these need to be globally accessible.

function updateToggle(element) { // 'element' here is the HTML element itself
    // When called via addEventListener, 'element' is the Event object.
    // The actual checkbox element is event.target.
    const targetCheckbox = element.target;
    const id = targetCheckbox.id;
    const isChecked = targetCheckbox.checked;
    const idLength = id.length;
    const togType = id.charAt(0);
    let toggNumber;

    if (idLength == 8) { toggNumber = id.substring(7); }
    else if (idLength == 9) { toggNumber = id.substring(7); }
    else { console.error("Unexpected toggle ID format:", id); toggNumber = id.substr(idLength - (idLength - "toggle".length - 1)); }

    console.log("Toggle Event: " + id + ", Checked: " + isChecked + ", Type: " + togType + ", Number: " + toggNumber);

    if (toggNumber == "8" && togType == "D") {
        if (isChecked) {
            if (logRefreshIntervalId) clearInterval(logRefreshIntervalId);
            loadErrorLogTable();
            logRefreshIntervalId = setInterval(loadErrorLogTable, 15000);
        } else {
            if (logRefreshIntervalId) clearInterval(logRefreshIntervalId);
            logRefreshIntervalId = null;
        }
    }
    if (websocket && websocket.readyState === WebSocket.OPEN) {
        const message = toggNumber + togType + (isChecked ? "1" : "0");
        websocket.send(message);
    }
}

function forceWifiScan() {
    if (websocket && websocket.readyState === WebSocket.OPEN) {
        websocket.send("forceWifiScan");
        console.log("Sent: forceWifiScan");
        const statusEl = document.getElementById('saveStatus');
        if (statusEl) {
            statusEl.innerText = 'WiFi scan and reconnect initiated...';
            // Clear the message after a few seconds
            setTimeout(() => { if (statusEl.innerText === 'WiFi scan and reconnect initiated...') statusEl.innerText = ''; }, 5000);
        }
    } else {
        const statusEl = document.getElementById('saveStatus');
        if (statusEl) {
            statusEl.innerText = 'Error: WebSocket not connected.';
        }
        console.log('WebSocket not open. Cannot send forceWifiScan.');
    }
}

function requestFullHistory() {
    if (websocket && websocket.readyState === WebSocket.OPEN) {
        websocket.send("requestFullHistory");
        console.log("Sent: requestFullHistory");
    } else {
        console.log('WebSocket not open. Cannot send requestFullHistory.');
    }
}

function sendForm(event) {
    const inputElement = event.target;
    const id = inputElement.id;
    const value = inputElement.value;
    const idLength = id.length;
    const formType = id.charAt(0);
    let formNumber;

    if (idLength == 6) { formNumber = id.substr(idLength - 1, 1); }
    else if (idLength == 7) { formNumber = id.substr(idLength - 2, 2); }
    else if (idLength == 8) { formNumber = id.substr(idLength - 3, 3); }
    else { console.error("Unexpected number input ID format:", id); return; }

    console.log("Form Event: " + id + ", Value: " + value);
    if (websocket && websocket.readyState === WebSocket.OPEN) {
        const message = formNumber + formType + value;
        websocket.send(message);
    }
}

function updateTimeInput(element) {
    // This function might be redundant if covered by sendForm or needs specific logic
    console.log("Time Input Changed (not yet sending):", element.id, element.value);
    // If time inputs should also use sendForm logic, ensure their IDs match the pattern
    // or create a specific sender for them.
}

function getDropdown(element) {
    // This function might be redundant if covered by sendForm or needs specific logic
    console.log("Dropdown Changed (not yet sending):", element.id, element.value);
}
